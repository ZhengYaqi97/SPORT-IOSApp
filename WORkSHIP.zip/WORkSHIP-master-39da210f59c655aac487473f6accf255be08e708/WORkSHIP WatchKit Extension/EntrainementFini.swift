//
//  EntrainementFini.swift
//  WORkSHIP
//
//  Created by Yaqi Zheng on 09/04/2018.
//  Copyright © 2018 Cyril Gourgouillon. All rights reserved.
//

import Foundation

class EntrainementFini{
    var nbentfini = Int()
    var description: String{
        return "vous avez fini \(nbentfini) exercice"
    }
    /*class func toString(){
        let nbentfini:Int="0"
        let entrainementfini=nbentfini.toString()
    }*/
    init(nbentfini:Int){
        self.nbentfini=nbentfini
    }
    
    convenience init(){
        self.init(nbentfini:0)
    }
    
}
