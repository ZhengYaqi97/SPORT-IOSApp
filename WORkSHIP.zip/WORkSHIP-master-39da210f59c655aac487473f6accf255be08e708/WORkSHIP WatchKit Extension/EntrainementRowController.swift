//
//  EntrainementRowController.swift
//  WORkSHIP WatchKit Extension
//
//  Created by Cyril Gourgouillon on 12/03/2018.
//  Copyright © 2018 Cyril Gourgouillon. All rights reserved.
//

import WatchKit

class EntrainementRowController: NSObject {

    @IBOutlet var entrainementLabel: WKInterfaceLabel!
    
    var entrainement: Entrainement? {
        // 2
        didSet {
            // 3
            guard let entrainement = entrainement else { return }
            // 4
            entrainementLabel.setText(entrainement.nom)
        }
    }

}
