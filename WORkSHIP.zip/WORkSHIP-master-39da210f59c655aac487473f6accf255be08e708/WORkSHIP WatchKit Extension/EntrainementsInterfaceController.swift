//
//  EntrainementsInterfaceController.swift
//  WORkSHIP WatchKit Extension
//
//  Created by Cyril Gourgouillon on 12/03/2018.
//  Copyright © 2018 Cyril Gourgouillon. All rights reserved.
//

import WatchKit
import Foundation


class EntrainementsInterfaceController: WKInterfaceController {

    @IBOutlet var entrainementsTable: WKInterfaceTable!
    
    var entrainements = Entrainement.allEntrainement()
    
    override func table(_ table: WKInterfaceTable, didSelectRowAt rowIndex: Int) {
        let entrainement = entrainements[rowIndex]
        presentController(withName: "Entrainement", context: entrainement)
    }
    
    override func awake(withContext context: Any?) {
        
        super.awake(withContext: context)
        entrainementsTable.setNumberOfRows(entrainements.count, withRowType: "EntrainementRow")
        
        for index in 0..<entrainementsTable.numberOfRows {
            guard let controller = entrainementsTable.rowController(at: index) as? EntrainementRowController else { continue }
            
            controller.entrainement = entrainements[index]
        }
    }
}
						
