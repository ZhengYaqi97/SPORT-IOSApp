//
//  EntrainementStatistique.swift
//  WORkSHIP WatchKit Extension
//
//  Created by Yaqi Zheng on 26/03/2018.
//  Copyright © 2018 Cyril Gourgouillon. All rights reserved.
//

import WatchKit
import Foundation


class EntrainementStatistique: WKInterfaceController {
    
    @IBOutlet var TitreFini: WKInterfaceLabel!
    
    @IBOutlet var separator: WKInterfaceSeparator!
    
    
    @IBOutlet var NBfini: WKInterfaceLabel!
    
    var entrainementFini : Int = 0
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
       
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        NBfini.setText("1")
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    override init() {
        // Initialize properties here.
        super.init()
        
        
        // It is now safe to access interface objects.
        
    }
    
    
}
