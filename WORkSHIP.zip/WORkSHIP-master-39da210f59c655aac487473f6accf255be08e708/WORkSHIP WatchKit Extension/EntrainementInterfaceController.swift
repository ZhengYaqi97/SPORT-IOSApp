//
//  EntrainementInterfaceController.swift
//  WORkSHIP WatchKit Extension
//
//  Created by Cyril Gourgouillon on 12/03/2018.
//  Copyright © 2018 Cyril Gourgouillon. All rights reserved.
//

import WatchKit
import Foundation


class EntrainementInterfaceController: WKInterfaceController {
    
    @IBOutlet var titreEntrainement: WKInterfaceLabel!
    
    @IBOutlet var pausePlayBtn: WKInterfaceButton!
    
    @IBOutlet var timerLabel : WKInterfaceLabel!
    
    @IBOutlet var minuteLabel : WKInterfaceLabel!
    
    @IBOutlet var BtnStatistique: WKInterfaceButton!
    
    
    var myTimer : Timer?  //internal timer to keep track
    var isPaused = true //flag to determine if it is paused or not
    
    var duration : Int = 0
    var minute : Int = 0
    var second : Int = 0
    var entrainementfini : Int = 0
    
    
    var entrainement: Entrainement? {
        didSet {
            guard let entrainement = entrainement else { return }
            titreEntrainement.setText(entrainement.nom)
        }
    }
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        if let entrainement = context as? Entrainement {
            self.entrainement = entrainement
            duration = Int(entrainement.sec)!
            
            if let entrainementfini = context as? EntrainementFini{self.entrainementfini = entrainementfini.nbentfini}
            
        }
        
        initialiserCounter(duration: Int(duration))
        
        
        pausePlayBtn.setTitle("Play")
    }
    
    func secondsToMinutesSeconds (seconds : Int) -> (Int, Int) {
        return ((seconds % 3600) / 60, (seconds % 3600) % 60)
    }
    
    func initialiserCounter (duration : Int) {
        (minute,second) = secondsToMinutesSeconds(seconds: Int(duration))
        print("minute : \(minute)")
        print("second : \(second)")
        if second > 9 {     timerLabel.setText("\(second)") }
        else {              timerLabel.setText("0\(second)")}
        
        if minute > 9 {     minuteLabel.setText("\(minute)")}
        else {              minuteLabel.setText("0\(minute)")}
    }
    
    @objc func counter(){
        if second != 0 {
            second -= 1
            if second > 9 {
                timerLabel.setText("\(second)")
            }
            else {
                timerLabel.setText("0\(second)")
            }
            if minute == ((duration % 3600) % 60) {
                minute -= 1
                minuteLabel.setText(String(minute))
            }
            
        }
        else if second == 0{
            second = 59
            timerLabel.setText("\(second)")
            if minute != 0 {
                minute -= 1
                if minute > 9 {
                    minuteLabel.setText("\(minute)")
                }
                else {
                    minuteLabel.setText("0\(minute)")
                }
            }
            else {
                myTimer?.invalidate()
                initialiserCounter(duration: duration)
                pausePlayBtn.setTitle("Play")
                isPaused = true
                
                
            }
        }
    }
    func calculer(){
        if second == 0{
            myTimer?.invalidate()
            timerLabel.setText("\(second)")
            entrainementfini+=1
        }
    }
    
    @IBAction func pauseResume() {
        //timer is paused. so unpause it and resume countdown
        if isPaused{
            isPaused = false
            myTimer = Timer.scheduledTimer(timeInterval: 1 , target: self, selector: #selector(EntrainementInterfaceController.counter), userInfo: nil, repeats: true)
            pausePlayBtn.setTitle("Pause")
        }
            //pause the timer
        else{
            isPaused = true
            
            //stop the ticking of the internal timer
            myTimer!.invalidate()
            
            //do whatever UI changes you need to
            pausePlayBtn.setTitle("Resume")
        }
    }
    
}

