//
//  File.swift
//  WORkSHIP WatchKit Extension
//
//  Created by Cyril Gourgouillon on 12/03/2018.
//  Copyright © 2018 Cyril Gourgouillon. All rights reserved.
//

import Foundation

class Entrainement {
    let nom: String
    let sec: String
    
    
    class func allEntrainement() -> [Entrainement] {
        
        var entrainements: [Entrainement] = []
        
        guard let path = Bundle.main.path(forResource: "Entrainements", ofType: "json"),
            let data = try? Data(contentsOf: URL(fileURLWithPath: path)) else {
                return entrainements
        }
        
        do {
            let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! [[String: String]]
            json.forEach({ (dict: [String: String]) in
                entrainements.append(Entrainement(dictionary: dict))
            })
        } catch let error as NSError {
            print(error)
        }
        
        return entrainements
    }
    
    init(nom: String, sec: String) {
        self.nom = nom
        self.sec = sec
        
    }
    
    convenience init(dictionary: [String: String]) {
        let nom = dictionary["nom"]!
        let sec = dictionary["sec"]!
        
        self.init(nom: nom, sec: sec)
    }
}
