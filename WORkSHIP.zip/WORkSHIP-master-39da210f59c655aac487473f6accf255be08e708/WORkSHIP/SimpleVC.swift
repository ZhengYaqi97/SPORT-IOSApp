//
//  SimpleVC.swift
//  WORkSHIP
//
//  Created by Sandrine Guaffi on 20/02/2018.
//  Copyright © 2018 Cyril Gourgouillon. All rights reserved.
//

import UIKit

class SimpleVC: UIViewController {
    
    func navigationController(_ navigationController: UINavigationController,
                              willShow viewController: UIViewController,
                              animated: Bool){
        
    }
    
   
    @IBOutlet weak var sportImage: UIImageView!
    var imageNom: String?
    
    var nomEnt : String = ""
    
    @IBOutlet weak var repet: UILabel!
    @IBOutlet weak var plusMoins: UIStepper!
    @IBOutlet weak var btnAjouter: UIButton!
    
    
    
    @IBAction func ajt(_ sender: Any)
    {
        self.repet.text = Int(self.plusMoins.value).description
    }
    
    
    
    @IBAction func btnAjter(_ sender: Any) {
        
    }


    override func viewDidLoad() {
        super.viewDidLoad()
    
        
       // _ = navigationController?.popViewController(animated: true)

        // Do any additional setup after loading the view.
        
        print(imageNom)
        sportImage.image = UIImage(named: imageNom!)
        
        self.title = imageNom
        print(self.title)
    
        print(nomEnt)
    }
    
    
    func customInit(imageNom: String)
    {
        self.imageNom = imageNom
    }
    
 

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier=="segueAjouter"{
            let destination = segue.destination as? EntViewController
            destination?.nameent = nomEnt
        }
    }
    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
