//
//  EntViewController.swift
//  WORkSHIP
//
//  Created by Sandrine Guaffi on 20/02/2018.
//  Copyright © 2018 Cyril Gourgouillon. All rights reserved.
//

import UIKit

class EntViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, ExpandableDelegate {
    
    
    
    

    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var noment: UITextField!
    
    var tabExo : [String : Double] = [:]
    
    var nameent : String = ""
    
    var sections = [
        Section(type: " 💪 : Bras" , exercice: ["Pompes", "Triceps", "Cercle avec les bras" , "Escalade", "Planche"], expanded: false ),
        Section(type: " 🤽 : Abdos" , exercice: ["Crunch abdos", "Crunch bras etendu", "Twist russe" , "Cobra", "Planche"], expanded: false ),
        Section(type: " 🍑 : Fesses" , exercice: ["Squat", "Feinte arriere", "Donkey kicks" , "Pont", "La chaise"], expanded: false ),
        Section(type: " 👣 : Jambes" , exercice: ["Fentes", "Montee de genoux", "Squat du sumo" , "Leve de jambes allonges", "Adducteurs lateraux couches"], expanded: false )
    ]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view.
        noment.text = nameent
        let alert = UIAlertController(title: "Alerte", message: "Voulez-vous créer un nouvel entrainement ?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Oui", style: .default, handler: { (action) in
            
        }))
        alert.addAction(UIAlertAction(title: "Annuler", style : .default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
        } ))
        self.present(alert, animated: true, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sections[section].exercice.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 44
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (sections[indexPath.section].expanded)
        {
            return 44
        }
        else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 2
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = Expandable()
        header.customInit(title: sections[section].type , section: section, delegate: self as ExpandableDelegate)
        return header
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "labelcell")!
        cell.textLabel?.text = sections[indexPath.section].exercice[indexPath.row]
        return cell
    }
    
    
    func toggleSection(header: Expandable, section: Int) {
        sections[section].expanded = !sections[section].expanded
        
        
        tableView.beginUpdates()
        for i in 0 ..< sections[section].exercice.count {
            tableView.reloadRows(at: [IndexPath(row: i, section : section)], with: .automatic)
        }
        tableView.endUpdates()
    }
    
    /*func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let simpleVC = SimpleVC()
        print(sections[indexPath.section].exercice[indexPath.row])
        simpleVC.customInit(imageNom: sections[indexPath.section].exercice[indexPath.row])
        tableView.deselectRow(at: indexPath, animated: true)
        self.navigationController?.pushViewController(simpleVC, animated: true)
        
        print("didSelectRow")
        
    }*/
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("prepare")
        if segue.identifier == "segueID"{
            let destination = segue.destination as? SimpleVC
            //let pageIndex = tableView.indexPathForSelectedRow?.row
            destination?.imageNom = String(describing: sections[(tableView.indexPathForSelectedRow?.section)!].exercice[(tableView.indexPathForSelectedRow?.row)!])
            destination?.nomEnt = noment.text!
            
        }
        else if segue.identifier == "voirEnt"{
            let destination = segue.destination as? ExerciceViewController
            //let pageIndex = tableView.indexPathForSelectedRow?.row
            let che = noment.text!
            print(che)
            destination?.nom = che
            
            
        }
    }
    
    @IBAction func retourAjouter(segue : UIStoryboardSegue){
        noment.text = nameent
    }
    
    

    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
