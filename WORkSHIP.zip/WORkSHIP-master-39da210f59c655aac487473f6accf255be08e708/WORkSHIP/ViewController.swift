//
//  ViewController.swift
//  WORkSHIP
//
//  Created by Cyril Gourgouillon on 06/02/2018.
//  Copyright © 2018 Cyril Gourgouillon. All rights reserved.
//

import UIKit

class ViewController: UIViewController{


    @IBOutlet weak var btnGo: UIButton!
    @IBOutlet weak var btnInscrire: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        btnGo.layer.cornerRadius = 10
        btnGo.clipsToBounds = true
        btnInscrire.layer.cornerRadius = 10
        btnInscrire.clipsToBounds = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
    

}
