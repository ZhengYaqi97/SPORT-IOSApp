//
//  Section.swift
//  WORkSHIP
//
//  Created by Sandrine Guaffi on 20/02/2018.
//  Copyright © 2018 Cyril Gourgouillon. All rights reserved.
//

import Foundation

struct Section {
    var type: String!
    var exercice: [String]!
    var expanded: Bool!
    
    init(type: String, exercice: [String], expanded: Bool) {
        self.type = type
        self.exercice = exercice
        self.expanded = expanded
    }
}
