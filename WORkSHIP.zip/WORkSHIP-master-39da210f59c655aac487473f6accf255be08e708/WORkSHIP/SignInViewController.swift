//
//  SignInViewController.swift
//  WORkSHIP
//
//  Created by Cyril Gourgouillon on 12/02/2018.
//  Copyright © 2018 Cyril Gourgouillon. All rights reserved.
//

import UIKit

class SignInViewController: UIViewController {
    
    @IBOutlet weak var nom: UITextField!
    @IBOutlet weak var prenom: UITextField!
    @IBOutlet weak var genre: UISegmentedControl!
    @IBOutlet weak var mail: UITextField!
    @IBOutlet weak var mdp: UITextField!
    @IBOutlet weak var confirmationMDP: UITextField!
    @IBOutlet weak var DateNssce: UIDatePicker!
    @IBOutlet weak var btnInscrire: UIButton!
    
    
    
    @IBOutlet weak var datePickerTxt: UITextField!
    
    //let datePicker = UIDatePicker()
    
    func createDatePicker() {
        
        // format for picker
        DateNssce.datePickerMode = .date
        
        // toolbar
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        // bar button item
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([doneButton], animated: false)
        
        //datePickerTxt.inputAccessoryView = toolbar
        // assigning date picker to text field
        // datePickerTxt.inputView = DateNssce
    }
    
    @objc func donePressed() {
        
        // format date
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        dateFormatter.timeStyle = .none
        
        datePickerTxt.text = dateFormatter.string(from: DateNssce.date)
        self.view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createDatePicker()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
