//
//  ExerciceViewController.swift
//  WORkSHIP
//
//  Created by Sandrine Guaffi on 19/03/2018.
//  Copyright © 2018 Cyril Gourgouillon. All rights reserved.
//
import UIKit

class ExerciceViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var table: UITableView!
    @IBOutlet weak var btnEdite: UIButton!
    
    
    var nom : String = ""
    
    @IBOutlet weak var nameEnt: UILabel!
    
    var data : [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        table.dataSource = self
        table.delegate = self
        //self.table.isEditing = true
        //self.navigationItem.rightBarButtonItem = self.editButtonItem
        // Do any additional setup after loading the view.
        nameEnt.text = nom
    }
    override func viewDidAppear(_ animated: Bool){
        super.viewDidAppear(false)
        //super.viewD
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //1. Récupération du bon élément dans notre tableau data
        let d = data[indexPath.row]
        
        //2. Utilisation d'une cellule existante ou création d'une nouvelle cellule
        let cellIdentifier = "ElementCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) ?? UITableViewCell(style: .subtitle, reuseIdentifier: cellIdentifier)
        
        //3. Ajout des informations dans le champ texte de cellule
        cell.textLabel?.text = d
        cell.detailTextLabel?.text = "Exercice"
        
        //4. Renvoie de la cellule
        return cell
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let item = data[sourceIndexPath.row]
        data.remove(at: sourceIndexPath.row)
        data.insert(item, at: destinationIndexPath.row)
        
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCellEditingStyle.delete
        {
            data.remove(at: indexPath.row)
            tableView.reloadData()
        }
    }
    @IBAction func edite(_ sender: Any) {
        table.isEditing = !table.isEditing
        
        switch table.isEditing {
        case true:
            btnEdite.setTitle("done", for: .normal)
        case false:
            btnEdite.setTitle("edit", for: .normal)
        }
        
}

}
