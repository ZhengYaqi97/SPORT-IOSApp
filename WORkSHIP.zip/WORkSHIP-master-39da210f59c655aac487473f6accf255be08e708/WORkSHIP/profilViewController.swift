//
//  profilViewController.swift
//  WORkSHIP
//
//  Created by Sandya Soma Soundaram on 22/03/2018.
//  Copyright © 2018 Cyril Gourgouillon. All rights reserved.
//

import UIKit

class profilViewController: UIViewController {

    @IBOutlet weak var lblIMC: UILabel!
    @IBOutlet weak var lblPoids: UILabel!
    @IBOutlet weak var TFpoids: UITextField!
    @IBOutlet weak var TFtaille: UITextField!
    @IBOutlet weak var btnRefresh: UIButton!
    
    @IBAction func actionRefresh(_ sender: Any) {
        lblIMC.text = String(Double(TFpoids.text!)!/(Double(TFtaille.text!)!*Double(TFtaille.text!)!))
        if ((Double(TFpoids.text!)!/(Double(TFtaille.text!)!*Double(TFtaille.text!)!)) < 16.5) {
            lblPoids.text = "denutrition"
        }
        else if ((Double(TFpoids.text!)!/(Double(TFtaille.text!)!*Double(TFtaille.text!)!)) < 18.5) {
            lblPoids.text = "maigreur"
        }
        else if ((Double(TFpoids.text!)!/(Double(TFtaille.text!)!*Double(TFtaille.text!)!)) < 25) {
            lblPoids.text = "corpulence normale"
        }
        else if ((Double(TFpoids.text!)!/(Double(TFtaille.text!)!*Double(TFtaille.text!)!)) < 30) {
            lblPoids.text = "surpoids"
        }
        else if ((Double(TFpoids.text!)!/(Double(TFtaille.text!)!*Double(TFtaille.text!)!)) < 35) {
            lblPoids.text = "obésité modérée"
        }
        else if ((Double(TFpoids.text!)!/(Double(TFtaille.text!)!*Double(TFtaille.text!)!)) < 40) {
            lblPoids.text = "obésité sévère"
        }
        else {
            lblPoids.text = "obésité massive"
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
